<?php
$ticket_number = $_POST['ticket_id'];
$emails = $_POST['email_ids'];
//$ticket_number = '1588292763';
//$to = 'ajitsands@gmail.com';
$to = 'sajinhentry@gmail.com';
$subject = 'Car Parking QR Code Coupon';
$message = 'This is the coupon for car parking, Please see the attachment.';

// Set up the MIME boundary
$semi_rand = md5(time());
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";

// Headers for attachment
$headers = "From: noreply@somyagyabahrain.com\r\n";
$headers .= "Reply-To: noreply@somyagyabahrain.com\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: multipart/mixed;\r\n";
$headers .= " boundary=\"{$mime_boundary}\"";

// Define text parts
$email_message = "This is a multi-part message in MIME format.\n\n";
$email_message .= "--{$mime_boundary}\n";
$email_message .= "Content-Type: text/plain; charset=\"iso-8859-1\"\n";
$email_message .= "Content-Transfer-Encoding: 7bit\n\n";
$email_message .= $message . "\n\n";

// Attach files
$file = 'barcode/qr/temp/'.$ticket_number.'_car_pass.png';
$file_content = file_get_contents($file);
$file_name = basename($file);
$email_message .= "--{$mime_boundary}\n";
$email_message .= "Content-Type: application/octet-stream;\n";
$email_message .= " name=\"{$file_name}\"\n";
$email_message .= "Content-Transfer-Encoding: base64\n\n";
$email_message .= chunk_split(base64_encode($file_content)) . "\n";

// Send the email
$mail_sent = mail($to, $subject, $email_message, $headers);

// Check if the email was sent successfully
if ($mail_sent) {
    echo "Email sent successfully.";
    
    UpdateStatus($ticket_number);
    
} else {
    echo "Email sending failed.";
}


function UpdateStatus($ticket_number)
{
    $con = mysqli_connect("localhost","sianlab_dthuser","s@nds1@b","sianlab_carpark");
        
      if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
        

$sql= "update car_user_details set email_status='Send' where ticket_id='".$ticket_number."'";

$result = mysqli_query($con,$sql);

$con->close();

}