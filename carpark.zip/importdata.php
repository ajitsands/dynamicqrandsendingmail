<?php

// Database connection
$conn = mysqli_connect("localhost","somyagya_ticket_user","s@nds1@b","somyagya_wp_qriro");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Path to the CSV file
$csvFile = 'newdata.csv';

// Read the CSV file
if (($handle = fopen($csvFile, "r")) !== FALSE) {
    // Assuming the first row contains column names
    $headers = fgetcsv($handle, 1000, ",");
    
    // Assuming ticket_id is the second column in the CSV file
    $ticketIdIndex = array_search('ticket_id', $headers);
    if ($ticketIdIndex === false) {
        die("Ticket ID column not found in CSV file.");
    }
    
    // Iterate through each row in the CSV file
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $ticketId = $data[$ticketIdIndex];
        
        // Check if ticket ID already exists in the database
        $query = "SELECT ticket_id FROM car_user_details WHERE ticket_id = '" . $conn->real_escape_string($ticketId) . "'";
        $result = $conn->query($query);
        if ($result->num_rows == 0) {
            // Ticket ID does not exist, insert into the table
            $values = array();
            // Skip the first column which is the primary key
            foreach ($data as $key => $value) {
                if ($key != 0) {
                    $values[] = "'" . $conn->real_escape_string($value) . "'";
                }
            }
            $sql = "INSERT INTO car_user_details (" . implode(',', array_slice($headers, 1)) . ") VALUES (" . implode(',', $values) . ")";
            if (!$conn->query($sql)) {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
    fclose($handle);
}

$conn->close();
?>
