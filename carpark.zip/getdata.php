<?PHP
$con = mysqli_connect("localhost","somyagya_ticket_user","s@nds1@b","somyagya_wp_qriro");
        
      if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
        

$sql= "select * from car_user_details";
$result = mysqli_query($con,$sql);

 while($row=mysqli_fetch_assoc($result))
 {
    $data['data'][]= $row;
 }
$con->close();

echo json_encode($data);

?>