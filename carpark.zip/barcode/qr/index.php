<?php    
 
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = '';

    include "qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
    
    $qrCodeText = $_POST['text'];
    //$filename = $PNG_TEMP_DIR.$qrCodeText.'_test.png';
   
        
        // user data
        $filename = $PNG_TEMP_DIR.$qrCodeText.'_car_pass.png';
        //QRcode::png($_POST['text'], $filename, 'L', 5, 5);    
        
  
  
  // Set the desired dimensions for the resized image
$newWidth = 1100; // New width of the image
$newHeight = 1100; // New height of the image

// Generate the QR code
QRcode::png($qrCodeText, $filename, 'Q', 10, 1);

// Load the generated QR code image
$originalImage = imagecreatefrompng($filename);

// Create a new blank image with the desired dimensions
$resizedImage = imagecreatetruecolor($newWidth, $newHeight);

// Resize the original image to fit the new dimensions
imagecopyresampled($resizedImage, $originalImage, 0, 0, 0, 0, $newWidth, $newHeight, imagesx($originalImage), imagesy($originalImage));

// Save or output the resized image
imagepng($resizedImage, '../temp/'.$qrCodeText.'_car_pass.png');

// Free up memory
imagedestroy($originalImage);
imagedestroy($resizedImage);
  
  
  
    //display generated file
    //echo $PNG_WEB_DIR.basename($filename) ;  
    //echo '<img src="../barcode/qr/temp/'.$qrCodeText.'_car_pass.png">';
    
    
        
    // benchmark
    //QRtools::timeBenchmark();    

?>