<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DataTables Example</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
</head>
<body>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Sl No</th>
                <th>Ticket ID</th>
                <th>Fname</th>
                <th>Lname</th>
                <th>Email</th>
                <th>Status</th>
                <th>Send</th>
              
                <!-- Add more columns if needed -->
            </tr>
        </thead>
        <tbody>
            <!-- Table body will be populated dynamically -->
        </tbody>
    </table>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

</body>
</html>


<script>
    $(document).ready(function() {
    // Fetch data from PHP using AJAX
    
   stock_approval_list = $('#example').DataTable( {
                
                 "ajax": {
                     'type': 'POST',
                     'url': 'getdata.php',
                    
                  },
                  
                 "language": {
                     "zeroRecords": "No records available",
                     "infoEmpty": "No records available",
                  },
                 "order": [[ 0, "asc" ]],
				 "bPaginate": false,
				 "bLengthChange": false,
				 "bFilter": true,
				 "bInfo": true,
				 "autoWidth": true,
                 "columns": [
                     
                    
					 { "data": "ids" },
                     { "data":  "ticket_id" },
					 { "data":  "f_name"},
					 { "data":  "l_name"},
					 { "data":  "email"},
					 { "data":  "email_status",
					     render: function ( data, type, rows, meta ) {
					         if(data=='Send')
					         {
					             str_active_statu = '<span class="badge text-bg-success">'+data+'</span>';
    								
    								return str_active_statu;
					         }
					         else
					         {
					            
					             str_active_statu = '<span class="badge text-bg-danger">'+data+'</span>';
    								
    								return str_active_statu;
					        
					         }
					     }
					 },
					 { "data":  "ticket_id",
					     
					     render: function ( data, type, rows, meta ) {
					         if(data!='NA')
					         {
                              	str_active_statu = '<button class="btn btn-primary btn-sm">SEND</button>';
    								
    								return str_active_statu;
					         } 
					         else
					         {  
					             
					             return null;
					         }
                         }
					 },
					 
					
					]
                 
             });
             
             
    $('#example tbody').on('click', 'button', function(){
	    
	
	   
	   	        var $row = $(this).closest('tr');
				var data = stock_approval_list.row($row).data();
				
	            var $row = $(this).closest('tr'); // Assuming you've already identified the row
                var data = stock_approval_list.row($row).data(); // Retrieve the data object for the row
                
                // Update the value of the 'email_status' column to 'SEND'
                data.email_status = 'Send';
                
                
	            
            	ticket_number =data.ticket_id;
            	emails = data.email;
            	fname = data.f_name;
            	lname = data.l_name;
        //	alert(fname+' '+lname);
        		//alert(ticket_number+'---'+emails);
        		$.post('send_mail.php',{ticket_id:ticket_number,email_ids:emails,names:fname+' '+lname}, function(ret){
        		    alert(ret);
        		    
        		    // Set the modified data back to the DataTable
                    stock_approval_list.row($row).data(data);
                    
                    // Optionally, redraw the DataTable to reflect the changes visually
                    stock_approval_list.draw();
	            
        		    
        		    
        		    //Email sent successfully.
        		});
    });
    
    
    
});

</script>