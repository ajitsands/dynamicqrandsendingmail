<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to add QR code onto an image

// Function to add QR code onto an image
function addQRCodeToImage($backgroundImagePath, $qrCodeText, $outputPath,$text) {
   
   // Load the background image
    $backgroundImage = imagecreatefromjpeg($backgroundImagePath);

   // Load the QR code image
    $qrCodeImage = imagecreatefromstring(file_get_contents($outputPath));

    //Get dimensions of the background image and QR code image
    $bgWidth = imagesx($backgroundImage);
    $bgHeight = imagesy($backgroundImage);
    $qrWidth = imagesx($qrCodeImage);
    $qrHeight = imagesy($qrCodeImage);

   // Calculate the position to overlay the QR code (center it)
    $x = ($bgWidth - $qrWidth) / 2;
    $y = ($bgHeight - $qrHeight) / 2;
 
    //Overlay the QR code onto the background image
    imagecopy($backgroundImage, $qrCodeImage, $x, $y+52, 0, 0, $qrWidth, $qrHeight);
   
    imagejpeg($backgroundImage, $outputPath);
//--------------------
$fontSize = 35;
    $backgroundImage = imagecreatefromjpeg($outputPath);
 //imagestring($backgroundImage,15, 300, 550, "Mukesh Bhatia", imagecolorallocate($backgroundImage, 0, 0, 0));
 $font = '../barcode/qr/temp/AovelSansRounded-rdDL.ttf';
 
 // Get the dimensions of the background image
$imageWidth = imagesx($backgroundImage);
$imageHeight = imagesy($backgroundImage);

// Get the bounding box of the text
$textBox = imagettfbbox($fontSize, 0, $font, $text);

// Calculate the width and height of the text
$textWidth = $textBox[2] - $textBox[0];
$textHeight = $textBox[7] - $textBox[1];

// Calculate the coordinates to center the text horizontally and vertically
$x = ($imageWidth - $textWidth) / 2;
$y = ($imageHeight + $textHeight) / 2;
 // This second parameter is The Font Size at the same time Line Number 41 imagettfbbox(35, 0, $font, $text); This 35 also should be the same value 
 imagettftext($backgroundImage, $fontSize, 0, $x, $y+260, imagecolorallocate($backgroundImage, 0, 0, 0), $font, $text);

// Save or output the modified image
imagejpeg($backgroundImage, $outputPath);
 
// Save the image with the QR code and text
 //imagepng($backgroundImage, $outputPath);

//--------------------



   // Save the final image with the QR code
   

   // Free memory
    imagedestroy($backgroundImage);
    imagedestroy($qrCodeImage);
}

// Example usage
$backgroundImagePath = 'CarParkingPass.jpg'; // Path to background image

$con = mysqli_connect("localhost","somyagya_ticket_user","s@nds1@b","somyagya_wp_qriro");
        
      if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
        else
        {
            echo "Connected <br>";
        }
$ctr=1;
$sql= "select * from car_user_details where ticket_id != 'NA'";
$result = mysqli_query($con,$sql);
 while($row=mysqli_fetch_assoc($result))
 {
    $qrCodeText = $row['ticket_id'];
    $text =  ucwords(strtolower($row['f_name'])).' '.ucwords(strtolower($row['l_name']));
    echo $ctr." - ".$qrCodeText."<br>";
    //include('../barcode/qr/index.php');
    $ch = curl_init();
                        $curlConfig = array(
                            CURLOPT_URL            => "https://somyagyabahrain.com/carpark/barcode/qr/index.php",
                            CURLOPT_POST           => true,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POSTFIELDS     => array(
                                'text' => $qrCodeText
                            )
                        );
                        curl_setopt_array($ch, $curlConfig);
                        $result_curl = curl_exec($ch);
                        curl_close($ch);
    
    $outputPath = '../barcode/qr/temp/'.$qrCodeText.'_car_pass.png';
    addQRCodeToImage($backgroundImagePath, $qrCodeText, $outputPath, $text);
    $ctr +=1;
 }

$con->close();
//$qrCodeText = '2725886972'; // Text to encode in QR code
//$text = "Mukesh Bhatia Kumar";







//---------------------Ecample---------------


// // Data to encode into the QR code
// $data = 'https://www.example.com';

// // Filename to save the PNG image
// $filename = 'example_qrcode.png';

// // Error correction level (options: 'L', 'M', 'Q', 'H')
// $errorCorrectionLevel = 'H';

// // Size of the QR code image in pixels
// $size = 10;

// // Margin around the QR code image in pixels
// $margin = 4;

// // Generate the QR code
// QRcode::png($data, $filename, $errorCorrectionLevel, $size, $margin);
?>





